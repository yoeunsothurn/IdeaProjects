import java.util.ArrayList;
import java.util.Scanner;

public class NumberListProgram {
    public static void main(String[] args) {
        // Create a Scanner object for user input
        Scanner scanner = new Scanner(System.in);

        // Create an ArrayList to store the numbers
        ArrayList<Integer> numberList = new ArrayList<>();

        // Input phase
        System.out.println("Enter a list of numbers (enter a non-integer to finish):");
        while (scanner.hasNextInt()) {
            int number = scanner.nextInt();
            numberList.add(number);
        }

        // Display the entered numbers
        System.out.println("Entered Numbers:");
        for (int number : numberList) {
            System.out.println(number);
        }

        // Close the Scanner
        scanner.close();
    }
}
